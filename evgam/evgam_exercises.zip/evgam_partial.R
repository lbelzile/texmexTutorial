## evgam: Generalised Additive Extreme Value Models
## Some exercises to help you get started
## 27/06/2021

## Q1

library(evgam)
data('COprcp')
COprcp <- cbind(COprcp, COprcp_meta[COprcp$meta_row, ])

## Q2

brks <- pretty(COelev$z, 50)
cols <- hcl.colors(length(brks) - 1, 'YlOrRd', rev = TRUE)
image(COelev, breaks = brks, col = cols, asp = 1)
colplot(COprcp_meta$lon, COprcp_meta$lat, COprcp_meta$elev, 
        breaks = brks, add = TRUE)

## Q3

threshold <- 11.4
COprcp$excess <- COprcp$prcp - threshold
COprcp$excess[COprcp$excess <= 0] <- NA
fmla_gpd <- list(excess ~ s(lon, lat, k = 20) + s(elev, bs = 'cr'), 
  ~ s(lon, lat, k = 15))
m_gpd <- evgam(fmla_gpd, COprcp, family = 'gpd')
plot(m_gpd)

## Q4

# set up plotting data
COprcp_plot <- expand.grid(lon = COelev$x, lat = COelev$y)
COprcp_plot$elev <- as.vector(COelev$z)
pred_gpd <- predict(m_gpd, COprcp_plot, type = 'response')
# scale
pred_scale <- array(pred_gpd$scale, dim(COelev$z))
par(mfrow = c(1, 2))
image(COelev$x, COelev$y, pred_scale, asp = 1)
# shape
pred_shape <- array(pred_gpd$shape, dim(COelev$z))
image(COelev$x, COelev$y, pred_shape, asp = 1)

