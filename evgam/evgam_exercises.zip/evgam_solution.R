## evgam: Generalised Additive Extreme Value Models
## Some exercises to help you get started
## 27/06/2021

## Q1

library(evgam)
data('COprcp')
COprcp <- cbind(COprcp, COprcp_meta[COprcp$meta_row, ])

## Q2

brks <- pretty(COelev$z, 50)
cols <- hcl.colors(length(brks) - 1, 'YlOrRd', rev = TRUE)
image(COelev, breaks = brks, col = cols, asp = 1)
colplot(COprcp_meta$lon, COprcp_meta$lat, COprcp_meta$elev, 
        breaks = brks, add = TRUE)

## Q3

threshold <- 11.4
COprcp$excess <- COprcp$prcp - threshold
COprcp$excess[COprcp$excess <= 0] <- NA
fmla_gpd <- list(excess ~ s(lon, lat, k = 20) + s(elev, bs = 'cr'), 
  ~ s(lon, lat, k = 15))
m_gpd <- evgam(fmla_gpd, COprcp, family = 'gpd')
plot(m_gpd)

## Q4

# set up plotting data
COprcp_plot <- expand.grid(lon = COelev$x, lat = COelev$y)
COprcp_plot$elev <- as.vector(COelev$z)
pred_gpd <- predict(m_gpd, COprcp_plot, type = 'response')
# scale
pred_scale <- array(pred_gpd$scale, dim(COelev$z))
par(mfrow = c(1, 2))
image(COelev$x, COelev$y, pred_scale, asp = 1)
# shape
pred_shape <- array(pred_gpd$shape, dim(COelev$z))
image(COelev$x, COelev$y, pred_shape, asp = 1)

## Q5

fmla_gpd2 <- list(excess ~ te(lon, lat) + s(elev, bs = 'cr'), 
  ~ te(lon, lat))
m_gpd2 <- evgam(fmla_gpd2, COprcp, family = 'gpd')
plot(m_gpd2)

## Q6

# quantile regression
fmla_ald <- list(prcp ~ s(lon, lat) + s(elev, bs = 'cr'), ~ 1)
m_ald <- evgam(fmla_ald, COprcp, family = 'ald', ald.args = list(tau = .95))
COprcp$p95 <- predict(m_ald)$location
COprcp$excess2 <- COprcp$prcp - COprcp$p95
COprcp$excess2[COprcp$excess2 < 0] <- NA

# GPD model
fmla_gpd3 <- list(excess2 ~ s(lon, lat, k = 20) + s(elev, bs = 'cr'), 
  ~ s(lon, lat, k = 15))
m_gpd3 <- evgam(fmla_gpd3, COprcp, family = 'gpd')

# plotting data
COprcp_plot$location <- predict(m_ald, COprcp_plot)$location
pred_gpd3 <- predict(m_gpd3, COprcp_plot, type = 'response')
COprcp_plot[, c('scale', 'shape')] <- pred_gpd3
rl_gpd <- function (p, loc, scale, shape, tau) {
  loc + scale * (((1 - p) / (1 - tau))^(-shape) - 1) / shape
}
pred_rl100 <- rl_gpd(0.99, COprcp_plot$location, COprcp_plot$scale, COprcp_plot$shape, 0.95)
image(COelev$x, COelev$y, array(pred_rl100, dim(COelev$z)), asp = 1)

